const users = require("./users");
const boards = require("./boards");


module.exports = {users, boards};