alreadyLikeBtn.onclick = function(e) {
    e.preventDefault();
}

