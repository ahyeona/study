// 이메일 비밀번호 닉네임 공백, 정규식 확인





// signupBtn.onclick = function (e) {
//     e.preventDefault();
//     alert("dfdfdf");
// }

// // 이메일 중복확인
// emailCheckBtn.onclick = function (e) {

//     let emailForm = document.createElement('form');
//     let input = document.createElement('input');

//     input.setAttribute('type', 'hidden');
//     input.setAttribute('name', 'email');
//     input.setAttribute('value', email.value);
//     emailForm.appendChild(input);
//     emailForm.setAttribute('method', 'post');
//     emailForm.setAttribute('action', '/users/emailcheck');

//     document.body.appendChild(emailForm);
//     emailForm.submit();

// }
